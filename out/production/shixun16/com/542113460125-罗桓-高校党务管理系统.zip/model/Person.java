package com.model;

/**
 * person表实体 规定政治面貌只有 群众 共青团员 积极分子 预备党员 党员
 */
public class Person {
    private String 政治面貌;
}
