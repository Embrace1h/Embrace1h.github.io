/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 8.0.28 : Database - system
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `system`;

/*Table structure for table `conference` */

DROP TABLE IF EXISTS `conference`;

CREATE TABLE `conference` (
  `记录人` varchar(20) NOT NULL,
  `开始时间` datetime NOT NULL,
  `结束时间` datetime NOT NULL,
  `党员人数` smallint NOT NULL,
  `主持人` varchar(20) NOT NULL,
  `会议主题` varchar(32) NOT NULL,
  `会议内容` varchar(1024) NOT NULL,
  PRIMARY KEY (`记录人`),
  CONSTRAINT `conference_ibfk_1` FOREIGN KEY (`记录人`) REFERENCES `information` (`姓名`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `conference` */

/*Table structure for table `information` */

DROP TABLE IF EXISTS `information`;

CREATE TABLE `information` (
  `id` int NOT NULL AUTO_INCREMENT,
  `姓名` varchar(10) NOT NULL,
  `性别` char(2) DEFAULT NULL,
  `出生日期` date DEFAULT NULL,
  `学历学位` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `籍贯` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `职务职称` varchar(8) DEFAULT NULL,
  `入党时间` varchar(10) DEFAULT NULL,
  `党内职务` varchar(8) DEFAULT NULL,
  `身份证号` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `政治面貌` varchar(10) DEFAULT NULL,
  `组织名称` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `userName` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `password` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `balance` double DEFAULT NULL,
  PRIMARY KEY (`姓名`),
  UNIQUE KEY `password` (`password`),
  UNIQUE KEY `userName` (`userName`),
  KEY `组织名称` (`组织名称`),
  KEY `政治面貌` (`政治面貌`),
  KEY `id` (`id`),
  CONSTRAINT `information_ibfk_1` FOREIGN KEY (`组织名称`) REFERENCES `organization` (`组织名称`),
  CONSTRAINT `information_ibfk_2` FOREIGN KEY (`政治面貌`) REFERENCES `person` (`政治面貌`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `information` */

insert  into `information`(`id`,`姓名`,`性别`,`出生日期`,`学历学位`,`籍贯`,`职务职称`,`入党时间`,`党内职务`,`身份证号`,`政治面貌`,`组织名称`,`userName`,`password`,`balance`) values 
(28,'刘一','女','1987-02-06','大学','山东','导员','2000-05-27','无','9846514','积极分子','zzuli','java3','0003',90),
(42,'刘娜','女','1988-06-05','博士','黑龙江','院士','1999-01-05','无','641364','党员','郑州轻工业大学','java13','00013',100),
(29,'张三','女','1989-06-09','大学','河北','教师','2001-06-23','无','4689654','党员','郑州大学','java4','0004',100),
(35,'桓','女','2004-07-15','本科','新乡','学生','','','410726','预备党员','zzuli','java6','0006',99),
(30,'武艺','男','1985-04-21','研究生','黑龙江','教授','','','3544534','积极分子','zzuli','java5','0005',100),
(26,'管理员','','2000-01-01','研究生','中国','码农','0000-00-00','无','10000','党员','zzuli','java1','0001',100),
(44,'罗桓','女','2004-08-31','','','','','','','共青团员','郑州轻工业大学','java7','0007',NULL),
(41,'郭晓','女','2000-03-28','大学','河北','学生','','无','643511','共青团员','dd','java12','00012',100),
(27,'韩晓','男','2010-02-03','初中','河南','学生',NULL,NULL,'4613586','群众','zz','java2','0002',98),
(37,'高雄','男','1978-12-12','大学','湖北','学生','','','4616971','预备党员','zz','java8','0008',98);

/*Table structure for table `organization` */

DROP TABLE IF EXISTS `organization`;

CREATE TABLE `organization` (
  `编号` int NOT NULL AUTO_INCREMENT,
  `组织名称` varchar(20) NOT NULL,
  `组织编号` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `地址` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `支部书记` varchar(6) DEFAULT NULL,
  `委员` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`组织名称`),
  KEY `编号` (`编号`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `organization` */

insert  into `organization`(`编号`,`组织名称`,`组织编号`,`地址`,`支部书记`,`委员`) values 
(14,'dd','7564354','有','张三','王五'),
(9,'xx','564','有','wu','zhang'),
(15,'yy','12345','有','zs','lb'),
(8,'zz','345243','无','张','无'),
(3,'zzuli','324354','有','常书记','魏'),
(17,'河南大学','452300','无','刘文书记','茅斯'),
(18,'郑州大学','453210','无','左书记','左'),
(16,'郑州轻工业大学','54230','有','刘书记','张');

/*Table structure for table `person` */

DROP TABLE IF EXISTS `person`;

CREATE TABLE `person` (
  `政治面貌` varchar(10) NOT NULL,
  PRIMARY KEY (`政治面貌`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `person` */

insert  into `person`(`政治面貌`) values 
('党员'),
('共青团员'),
('积极分子'),
('群众'),
('预备党员');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

/*!50001 DROP VIEW IF EXISTS `user` */;
/*!50001 DROP TABLE IF EXISTS `user` */;

/*!50001 CREATE TABLE  `user`(
 `姓名` varchar(10) ,
 `userName` varchar(10) ,
 `password` varchar(20) 
)*/;

/*View structure for view user */

/*!50001 DROP TABLE IF EXISTS `user` */;
/*!50001 DROP VIEW IF EXISTS `user` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `user` AS select `information`.`姓名` AS `姓名`,`information`.`userName` AS `userName`,`information`.`password` AS `password` from `information` */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
